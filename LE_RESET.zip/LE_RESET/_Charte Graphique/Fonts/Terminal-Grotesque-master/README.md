# Terminal Grotesque

Open source pixel / grotesque font family.  
The font was initiated by Raphaël Bastide and completed by Jérémy Landes-Nones with the _open_ version.

## Specimen

![Specimen 1](https://raw.githubusercontent.com/raphaelbastide/Terminal-Grotesque/master/specimen/Terminal-Grotesque-specimen-1.png)

![Specimen 2](https://raw.githubusercontent.com/raphaelbastide/Terminal-Grotesque/master/specimen/Terminal-Grotesque-specimen-2.png)

## License

Terminal Grotesque is under [SIL Open Font License (OFL)](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL "SIL Open Font License")
